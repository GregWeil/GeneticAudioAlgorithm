/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-altivec.h"
#include "../common/n2bv_64.c"
