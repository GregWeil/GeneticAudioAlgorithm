/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-avx.h"
#include "../common/n2bv_6.c"
